import json
import os
import boto3
import uuid

# Get the DynamoDB table name from environment variables
DYNAMODB_TABLE = os.environ.get("DYNAMODB_TABLE", "")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(DYNAMODB_TABLE)

def lambda_handler(event, context):
    """
    Lambda function to create an item in DynamoDB.
    Expects POST request with JSON body containing 'name' and 'description'.
    """
    try:
        # Parse JSON body
        body = json.loads(event.get("body", "{}"))
        name = body.get("name")
        description = body.get("description")

        if not name or not description:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing 'name' or 'description'"})
            }

        # Create a unique item ID
        item_id = str(uuid.uuid4())

        # Put item into DynamoDB
        table.put_item(Item={
            "id": item_id,
            "name": name,
            "description": description
        })

        # Return success response
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Item created successfully",
                "id": item_id
            })
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal server error"})
        }
